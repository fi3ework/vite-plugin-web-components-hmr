---
name: Feature Request
about: You have an idea about an additional feature
title: '[Feature Request] please use the discussions tab'
labels: ''
assignees: ''
---

Please use [discussions](https://github.com/open-wc/open-wc/discussions/new) for new feature requests.
