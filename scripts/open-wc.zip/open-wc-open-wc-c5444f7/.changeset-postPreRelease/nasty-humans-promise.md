---
'eslint-plugin-lit-a11y': patch
---

Deprecate no-invalid-change-handler rule
