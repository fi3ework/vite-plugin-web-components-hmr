# `component-b`

## `success states`

####   `can ignore attributes`

```html
<div>
  A
</div>

```

```html
<div>
  A
</div>

```

## `error states`

####   `can ignore tags`

```html
<div>
  A
</div>

```

```html
<div>
  A
</div>

```

