# `Plugin - semantic-dom-diff`

#### `can compare against a snapshot`

```html
<div>
  <h1>
    Hey
  </h1>
</div>

```

