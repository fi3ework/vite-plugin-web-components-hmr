# Codelab A

## Step a

Do this:

```js
class Element extends LitElement {}
```

## Step b

Do that:

![logo](./assets/logo.png)
