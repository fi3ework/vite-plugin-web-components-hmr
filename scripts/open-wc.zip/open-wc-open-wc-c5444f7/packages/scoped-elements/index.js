/** @typedef {import('./src/types').ScopedElementsMap} ScopedElementsMap */

export { ScopedElementsMixin } from './src/ScopedElementsMixin.js';
