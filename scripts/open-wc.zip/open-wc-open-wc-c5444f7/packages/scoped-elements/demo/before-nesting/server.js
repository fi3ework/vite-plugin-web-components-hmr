module.exports = {
  rootDir: '../../',
  appIndex: 'packages/scoped-elements/demo/before-nesting/index.html',
  nodeResolve: true,
  open: true,
};
