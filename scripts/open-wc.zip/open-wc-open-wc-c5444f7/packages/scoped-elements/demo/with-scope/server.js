module.exports = {
  rootDir: '../../',
  appIndex: 'packages/scoped-elements/demo/with-scope/index.html',
  nodeResolve: true,
  open: true,
};
