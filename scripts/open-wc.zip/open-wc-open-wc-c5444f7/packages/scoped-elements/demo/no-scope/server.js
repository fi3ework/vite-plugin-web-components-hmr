module.exports = {
  rootDir: '../../',
  appIndex: 'packages/scoped-elements/demo/no-scope/index.html',
  nodeResolve: true,
  open: true,
};
