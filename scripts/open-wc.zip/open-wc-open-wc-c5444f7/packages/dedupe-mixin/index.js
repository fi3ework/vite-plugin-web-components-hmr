export { dedupeMixin } from './src/dedupeMixin.js';
