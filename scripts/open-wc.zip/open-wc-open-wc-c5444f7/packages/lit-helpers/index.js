export { ReadOnlyPropertiesMixin } from './src/read-only-properties-mixin.js';
export * from './src/spread.js';
