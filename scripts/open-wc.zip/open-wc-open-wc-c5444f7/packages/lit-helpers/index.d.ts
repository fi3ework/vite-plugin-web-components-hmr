export { ReadOnlyPropertiesMixin } from './src/read-only-properties-mixin';
export { spread, spreadEvents, spreadProps } from './src/spread';