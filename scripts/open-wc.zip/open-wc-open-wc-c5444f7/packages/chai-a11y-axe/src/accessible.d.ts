/// <reference path="../chai-a11y-axe-plugin.d.ts" />

/**
 * @param {any} chai
 * @param {any} utils
 */
export const chaiA11yAxe: (chai: any, utils: any) => void;
