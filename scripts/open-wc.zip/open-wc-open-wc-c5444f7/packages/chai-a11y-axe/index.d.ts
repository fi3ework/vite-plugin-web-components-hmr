export { chaiA11yAxe } from "./src/accessible.js";
