import module from './src/index.js';

const { hmrPlugin, presets, WC_HMR_MODULE_RUNTIME } = module;

export { hmrPlugin, presets, WC_HMR_MODULE_RUNTIME };
