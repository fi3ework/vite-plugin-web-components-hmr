- make sure there is a unique name

Document shortcomings:

- added properties
- added attributeChangedCallbacks
