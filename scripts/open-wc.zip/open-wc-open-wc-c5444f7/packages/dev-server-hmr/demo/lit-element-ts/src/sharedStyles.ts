import { css } from 'lit';

export const sharedStyles = css`
  .shared-template {
    color: green;
  }
`;
