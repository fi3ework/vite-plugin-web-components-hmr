import { html } from 'lit';

export const sharedTemplate = html`<p class="shared-template">Shared template</p>`;
