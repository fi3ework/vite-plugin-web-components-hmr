export const sharedTemplate = '<p class="shared-template">Shared template</p>';
