export const sharedStyles = `
  .shared-template {
    color: green;
  }
`;
