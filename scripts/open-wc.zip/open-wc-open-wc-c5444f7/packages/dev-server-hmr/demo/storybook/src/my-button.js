import { MyButton } from './MyButton.js';

customElements.define('my-button', MyButton);
