module.exports = {
  stories: ['../stories/**/*.stories.@(md|mdx)', '../stories/**/*.stories.@(js|jsx|ts|tsx)'],
  rollupConfig(config) {
    // console.log('rollup config', config);
  },
};
