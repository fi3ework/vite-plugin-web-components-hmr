import { html } from 'lit';

export const sharedStyles = html`
  <style>
    .shared-template {
      color: green;
    }
  </style>
`;
