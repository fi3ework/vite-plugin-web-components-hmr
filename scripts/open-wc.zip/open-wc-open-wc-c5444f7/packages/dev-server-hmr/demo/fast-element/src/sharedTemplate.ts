import { html } from '@microsoft/fast-element';

export const sharedTemplate = html`
  <p class="shared-template">Shared template</p>
`;
