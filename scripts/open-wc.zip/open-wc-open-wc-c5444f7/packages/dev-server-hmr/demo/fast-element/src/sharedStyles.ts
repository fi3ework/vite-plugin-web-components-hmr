import { css } from '@microsoft/fast-element';

export const sharedStyles = css`
  .shared-template {
    color: green;
  }
`;
