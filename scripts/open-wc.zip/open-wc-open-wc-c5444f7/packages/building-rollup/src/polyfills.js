const defaultPolyfills = {
  fetch: true,
  abortController: true,
  coreJs: true,
  webcomponents: true,
};

module.exports = { defaultPolyfills };
