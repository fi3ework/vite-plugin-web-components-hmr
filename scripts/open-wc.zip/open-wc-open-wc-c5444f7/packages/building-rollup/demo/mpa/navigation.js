export const navigationMetaUrl = import.meta.url;
