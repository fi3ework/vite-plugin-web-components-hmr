import { getDiffableHTML } from './get-diffable-html.js';

export {
  getDiffableHTML,
  // backwards compatible export
  getDiffableHTML as getDiffableSemanticHTML,
};

export { chaiDomDiff } from './chai-dom-diff.js';
