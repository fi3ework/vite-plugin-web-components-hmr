export function getMochaTestPath(runnable: any): any[];
export function getOuterHtml(el: Element): string;
export function getCleanedShadowDom(el: Element): string;
