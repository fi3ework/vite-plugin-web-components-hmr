export { chaiDomDiff } from "./chai-dom-diff.js";
import { getDiffableHTML } from "./get-diffable-html.js";
export { getDiffableHTML, getDiffableHTML as getDiffableSemanticHTML };
