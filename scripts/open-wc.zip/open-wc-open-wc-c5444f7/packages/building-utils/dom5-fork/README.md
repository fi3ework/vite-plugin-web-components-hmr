This is a "fork" of dom5. See [npm](https://www.npmjs.com/package/dom5) and [github source](https://github.com/Polymer/tools/tree/master/packages/dom5).

We will use it until [issues/3385](https://github.com/Polymer/tools/issues/3385) is resolved.
