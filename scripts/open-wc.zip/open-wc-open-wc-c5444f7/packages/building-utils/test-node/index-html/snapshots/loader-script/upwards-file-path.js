(function() {
  function loadEntries() {
    window.importShim('../app.js');
  }

  loadEntries()
})();