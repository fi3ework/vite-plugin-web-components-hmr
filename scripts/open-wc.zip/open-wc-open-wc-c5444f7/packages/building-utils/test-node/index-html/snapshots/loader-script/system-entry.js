(function() {
  function loadEntries() {
    System.import('./app.js');
  }

  loadEntries()
})();