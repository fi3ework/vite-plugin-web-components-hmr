import { DemoWcCard } from './src/DemoWcCard.js';

customElements.define('demo-wc-card', DemoWcCard);
