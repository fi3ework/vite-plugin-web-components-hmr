module.exports = {
  stories: ['../stories/*.stories.{js,md}'],
};
