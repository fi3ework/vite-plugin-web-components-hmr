```js script
export default { title: 'Docs only' };
```

# Docs only

This is a MD file with only docs

## Using 2 spaces to create a line break

x point 1  
x point 2  
x point 3

---

## Including an image

![mdjs logo](https://raw.githubusercontent.com/open-wc/open-wc/master/assets/images/logo.png)
