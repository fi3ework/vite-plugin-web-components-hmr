const { mdjsToCsf } = require('./src/mdjsToCsf.js');

module.exports = { mdjsToCsf };
