interface ImportMeta {
  url: string;
}
