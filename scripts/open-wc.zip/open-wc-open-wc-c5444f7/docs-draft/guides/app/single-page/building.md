# App >> Single Page App >> Building ||30

> This text is not yet written or polished - care to help?

If you are building a single page application we recommend [rollup](https://rollupjs.org/guide/en/) to build your app.

Take a look at our dedicated [building-rollup](/building/building-rollup.html) page which explains how to set up rollup. We ship a default config that you can use to set up your project, or you can use it as inspiration for your custom config.
