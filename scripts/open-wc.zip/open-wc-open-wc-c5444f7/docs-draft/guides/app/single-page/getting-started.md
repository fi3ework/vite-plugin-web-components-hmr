# App >> Single Page App >> Getting Started ||10

> This text is not yet written or polished - care to help?

Let's create a Single Page App (SPA).
