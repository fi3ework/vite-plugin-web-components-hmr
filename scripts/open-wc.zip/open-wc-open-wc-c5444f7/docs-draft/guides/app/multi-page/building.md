# App >> Multi Page App >> Building ||30

> This text is not yet written or polished - care to help?

Single page apps are great for a snappy user experience when you have highly dynamic content, but a lot of content on the web does not fall into this category. It still makes sense to build websites or apps consisting of multiple pages. This also requires a different approach to your build system.

We are still in the process of investigating and documenting our recommendations for this. In the meantime both [building-rollup](/building/building-rollup.html) and [@web/rollup-plugin-html](https://modern-web.dev/docs/building/rollup-plugin-html/) have tips for these types of projects.
