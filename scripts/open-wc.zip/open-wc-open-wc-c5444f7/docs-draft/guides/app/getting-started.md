# App >> Getting Started ||10

> This text is not yet written or polished - care to help?

Creating an application with web components comes down to two solutions.

- Single Page Application (SPA)
- Multi Page Application (MPA)

Let's compare them and what are the benefit for each approach.
