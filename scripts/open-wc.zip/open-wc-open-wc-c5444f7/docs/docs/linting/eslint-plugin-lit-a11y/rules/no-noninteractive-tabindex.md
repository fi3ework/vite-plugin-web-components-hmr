# Linting >> EsLint Plugin Lit A11y >> no-noninteractive-tabindex

Documentation is missing - care to contribute? 🙏
