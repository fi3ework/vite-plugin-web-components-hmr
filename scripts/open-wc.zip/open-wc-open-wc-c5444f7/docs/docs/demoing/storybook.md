# Demoing >> Storybook ||10

We now recommend to use the [@web/dev-server storybook plugin](https://modern-web.dev/docs/dev-server/plugins/storybook/) instead of the `@open-wc/demoing-storybook` packages.
