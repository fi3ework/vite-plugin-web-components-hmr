# Slack

You can also find us on the Lit & Friends slack in the [#open-wc](https://lit-and-friends.slack.com/archives/CE6D9DN05) channel.

You can join the Lit & Friends slack by visiting [https://lit.dev/slack-invite/](https://lit.dev/slack-invite/).
